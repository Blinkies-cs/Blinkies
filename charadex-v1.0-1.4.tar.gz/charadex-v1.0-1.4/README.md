# v.1.4

- Another semi-complete remake.
- JS has been overhauled, and hopefully easier to read?
- Downgraded to Bootstrap 4.5 since it is the closest to Toyhou.se's current version.
- Added dropdown to sort by any column you specify. (Default: Design Type)
- Added dropdown to search specific columns (such as only searching owners or artists)
- Added prev/next links on single entry page for better navigation
- Can now log multiple species! Hooray!
- Fixed issue where Google Sheets would not output JSON with a header.
- Updated look for the site template.
- 'Softer' load in so it's not as jarring (shout out to all my light-sensitive besties out there, may your eyes prosper in these dark times)
- Added more CSS variables for even easier customization
- Reorganized the HTML a bit for better readability